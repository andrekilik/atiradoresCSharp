﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Teste
{
    class Program
    {
        static public List<Atirador> atiralist = new List<Atirador> { };


        static void Main(string[] args)
        {
            Atirador a1 = new Atirador("Teste");
            Console.WriteLine(a1.name);
            bool gameEnd = false;
            List<String> namelist = new List<string> { "Pelé", "Batoré", "Caboré", "Jaspion", "Jiraya", "Jiban", "Samurai", "Oitaviano", "Nhonho", "Dexter" };
            int p = numPlayers();
            string previous = " ";
            int a = namelist.Count();
            for (int i = 0; i <= p; i++)
            {
                Random rndname = new Random();
                int ind = rndname.Next(namelist.Count);
                atiralist.Add(new Atirador(namelist[ind]));
                namelist.RemoveAt(ind);
                
            }
            while (gameEnd == false)
            {
                Atirador shooter = getShooter();
                Atirador taker   = getTaker(shooter);
                while (previous == shooter.name)
                {
                    shooter = getShooter();
                    taker = getTaker(shooter);
                }
                int turno = Atirador.atira(taker);
                Console.WriteLine(shooter.name + " Atira em " + taker.name);
                if (taker.vida <= 0)
                {
                    Console.WriteLine(taker.name + " Morreu");
                    atiralist.Remove(taker);
                }
                else
                {
                    Console.WriteLine(taker.name + " agora tem " + taker.vida);
                }
                previous = shooter.name;
                if (atiralist.Count == 1)
                {
                    Console.WriteLine(atiralist[0].name + " Ganhou o jogo");
                    gameEnd = true;
                }

            }
            
        }

        static Atirador getShooter()
        {
            Random rnd = new Random();
            int ind = rnd.Next(Program.atiralist.Count);
            Atirador shooter = Program.atiralist[ind];
            return shooter;
        }

        static Atirador getTaker(Atirador shooter)
        {
            Random rnd = new Random();
            int ind = rnd.Next(Program.atiralist.Count);
            Atirador taker = Program.atiralist[ind];
            while (shooter == taker)
            {
                ind = rnd.Next(Program.atiralist.Count);
                taker = Program.atiralist[ind];
            }
            return taker;
        }

        static int numPlayers()
        {
            while (true)
            {
                Console.WriteLine("Digite o número de jogadores");
                string playnumber = Console.ReadLine();
                if (Convert.ToInt32(playnumber) > 10)
                {
                    Console.WriteLine("Número máximo de jogadores deve ser 10");
                }
                else if (Convert.ToInt32(playnumber) < 2)
                {
                    Console.WriteLine("Mínimo de 2 Jogadores");
                }
                else return Convert.ToInt32(playnumber);
            }
        }
    }
}
