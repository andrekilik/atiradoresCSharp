﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Teste
{
    class Atirador
    {
        public string name;
        public int vida;
        private string status;
        public Atirador(string name)
        {
            this.name = name;
            vida = 5;
            status = "V";
        }

        static public int atira(Atirador target)
        {
            target.vida -= 1;
            return target.vida;
        }
    }
}
